export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyBEkYW8Hppigxyj-E8gtHuIoscSJ-oAKqI",
    authDomain: "ax121ahdhj1h31988910.firebaseapp.com",
    databaseURL: "https://ax121ahdhj1h31988910.firebaseio.com",
    projectId: "ax121ahdhj1h31988910",
    storageBucket: "ax121ahdhj1h31988910.appspot.com",
    messagingSenderId: "93712432849"
};